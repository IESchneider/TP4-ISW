﻿namespace TP1_TP6_ISW
{
    partial class Principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_CaracteresProd = new System.Windows.Forms.Label();
            this.txt_Productos = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txt_FechaEntrega = new System.Windows.Forms.MaskedTextBox();
            this.pic_Fecha = new System.Windows.Forms.PictureBox();
            this.txt_CostoProductos = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_AgregarFoto = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.pic_BorrarImagen = new System.Windows.Forms.PictureBox();
            this.pic_Logo1 = new System.Windows.Forms.PictureBox();
            this.lbl_CostoProductos = new System.Windows.Forms.Label();
            this.pic_ImagenAdjunta = new System.Windows.Forms.PictureBox();
            this.btn_Seguir = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.op_IngresarFechaHora = new System.Windows.Forms.RadioButton();
            this.op_LoAntesPosible = new System.Windows.Forms.RadioButton();
            this.lbl_Cuando = new System.Windows.Forms.Label();
            this.lbl_PedidoPersonalizado = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.txt_DirComercio = new System.Windows.Forms.TextBox();
            this.lbl_DirComercio = new System.Windows.Forms.Label();
            this.lbl_Direccion = new System.Windows.Forms.Label();
            this.cmb_CiudadComercio = new System.Windows.Forms.ComboBox();
            this.lbl_CiudadComercio = new System.Windows.Forms.Label();
            this.lbl_CaracteresRef = new System.Windows.Forms.Label();
            this.txt_ReferenciaComercio = new System.Windows.Forms.TextBox();
            this.lbl_ReferenciaComercio = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.txt_CostoTotal = new System.Windows.Forms.TextBox();
            this.pnl_Ruta = new System.Windows.Forms.Panel();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.cmb_CiudadDomicilio = new System.Windows.Forms.ComboBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.lbl_RefDomicilio = new System.Windows.Forms.Label();
            this.lbl_CaracteresRef2 = new System.Windows.Forms.Label();
            this.lbl_DirDomicilio = new System.Windows.Forms.Label();
            this.txt_RefDomicilio = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.txt_DirDomicilio = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lbl_Fin = new System.Windows.Forms.Label();
            this.pic_Mapa2 = new System.Windows.Forms.PictureBox();
            this.lbl_CiudadDomicilio = new System.Windows.Forms.Label();
            this.pic_Mapa = new System.Windows.Forms.PictureBox();
            this.lbl_Domicilio = new System.Windows.Forms.Label();
            this.lbl_Ingresar = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_Atras3 = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.pic_Logo3 = new System.Windows.Forms.PictureBox();
            this.btn_Confirmar = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.pnl_Tarjeta = new System.Windows.Forms.Panel();
            this.txt_NombreApellidoTitular = new System.Windows.Forms.TextBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.txt_NumeroTarjeta = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.txt_CodigoSeguridad = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.txt_Vencimiento = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pic_VisaGris = new System.Windows.Forms.PictureBox();
            this.pic_Visa = new System.Windows.Forms.PictureBox();
            this.lbl_CVC = new System.Windows.Forms.Label();
            this.lbl_NroTarjeta = new System.Windows.Forms.Label();
            this.lbl_FechaVencimiento = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTarjeta = new System.Windows.Forms.Label();
            this.pnl_Efectivo = new System.Windows.Forms.Panel();
            this.txt_EfectivoAPagar = new System.Windows.Forms.MaskedTextBox();
            this.pic_EfectivoPagar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_EnTotal = new System.Windows.Forms.TextBox();
            this.lbl_EnEnvio = new System.Windows.Forms.TextBox();
            this.lbl_EnProductos = new System.Windows.Forms.TextBox();
            this.txt_TotalProductos = new System.Windows.Forms.TextBox();
            this.txt_CostoEnvio = new System.Windows.Forms.TextBox();
            this.op_Tarjeta = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.op_Efectivo = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Atras2 = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.pic_Logo2 = new System.Windows.Forms.PictureBox();
            this.btn_Seguir2 = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pic_Logo4 = new System.Windows.Forms.PictureBox();
            this.btn_Cerrar = new TP1_TP6_ISW.Negocio.BotonRedondo();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Fecha)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_BorrarImagen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_ImagenAdjunta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            this.pnl_Ruta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Mapa2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Mapa)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo3)).BeginInit();
            this.pnl_Tarjeta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_VisaGris)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Visa)).BeginInit();
            this.pnl_Efectivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_EfectivoPagar)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo2)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.panel1.Controls.Add(this.lbl_CaracteresProd);
            this.panel1.Controls.Add(this.txt_Productos);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.txt_FechaEntrega);
            this.panel1.Controls.Add(this.pic_Fecha);
            this.panel1.Controls.Add(this.txt_CostoProductos);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.btn_AgregarFoto);
            this.panel1.Controls.Add(this.pic_BorrarImagen);
            this.panel1.Controls.Add(this.pic_Logo1);
            this.panel1.Controls.Add(this.lbl_CostoProductos);
            this.panel1.Controls.Add(this.pic_ImagenAdjunta);
            this.panel1.Controls.Add(this.btn_Seguir);
            this.panel1.Controls.Add(this.op_IngresarFechaHora);
            this.panel1.Controls.Add(this.op_LoAntesPosible);
            this.panel1.Controls.Add(this.lbl_Cuando);
            this.panel1.Controls.Add(this.lbl_PedidoPersonalizado);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(320, 561);
            this.panel1.TabIndex = 0;
            // 
            // lbl_CaracteresProd
            // 
            this.lbl_CaracteresProd.AutoSize = true;
            this.lbl_CaracteresProd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CaracteresProd.Font = new System.Drawing.Font("Poppins", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CaracteresProd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CaracteresProd.Location = new System.Drawing.Point(252, 204);
            this.lbl_CaracteresProd.Name = "lbl_CaracteresProd";
            this.lbl_CaracteresProd.Size = new System.Drawing.Size(41, 19);
            this.lbl_CaracteresProd.TabIndex = 13;
            this.lbl_CaracteresProd.Text = "0/240";
            this.lbl_CaracteresProd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_Productos
            // 
            this.txt_Productos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Productos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_Productos.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_Productos.Location = new System.Drawing.Point(27, 118);
            this.txt_Productos.MaxLength = 240;
            this.txt_Productos.Multiline = true;
            this.txt_Productos.Name = "txt_Productos";
            this.txt_Productos.Size = new System.Drawing.Size(265, 75);
            this.txt_Productos.TabIndex = 3;
            this.txt_Productos.Text = "Ingrese los productos aqui.";
            this.txt_Productos.Click += new System.EventHandler(this.txt_Productos_Click);
            this.txt_Productos.TextChanged += new System.EventHandler(this.txt_Productos_TextChanged);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text83;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(18, 109);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(283, 95);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 40;
            this.pictureBox4.TabStop = false;
            // 
            // txt_FechaEntrega
            // 
            this.txt_FechaEntrega.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_FechaEntrega.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_FechaEntrega.Location = new System.Drawing.Point(183, 463);
            this.txt_FechaEntrega.Mask = "00/00/0000 90:00";
            this.txt_FechaEntrega.Name = "txt_FechaEntrega";
            this.txt_FechaEntrega.Size = new System.Drawing.Size(114, 13);
            this.txt_FechaEntrega.TabIndex = 28;
            // 
            // pic_Fecha
            // 
            this.pic_Fecha.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text20tarjeta;
            this.pic_Fecha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_Fecha.Location = new System.Drawing.Point(175, 457);
            this.pic_Fecha.Name = "pic_Fecha";
            this.pic_Fecha.Size = new System.Drawing.Size(129, 26);
            this.pic_Fecha.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Fecha.TabIndex = 49;
            this.pic_Fecha.TabStop = false;
            // 
            // txt_CostoProductos
            // 
            this.txt_CostoProductos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CostoProductos.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_CostoProductos.Location = new System.Drawing.Point(26, 370);
            this.txt_CostoProductos.Name = "txt_CostoProductos";
            this.txt_CostoProductos.Size = new System.Drawing.Size(267, 13);
            this.txt_CostoProductos.TabIndex = 33;
            this.txt_CostoProductos.Text = "$___.___.___,__";
            this.txt_CostoProductos.Click += new System.EventHandler(this.txt_CostoProductos_format_Click);
            this.txt_CostoProductos.TextChanged += new System.EventHandler(this.txt_CostoProductos_format_TextChanged);
            this.txt_CostoProductos.Leave += new System.EventHandler(this.txt_CostoProductos_Leave);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(17, 363);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(284, 30);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 35;
            this.pictureBox3.TabStop = false;
            // 
            // btn_AgregarFoto
            // 
            this.btn_AgregarFoto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_AgregarFoto.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_AgregarFoto.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_AgregarFoto.BorderRadius = 20;
            this.btn_AgregarFoto.BorderSize = 0;
            this.btn_AgregarFoto.FlatAppearance.BorderSize = 0;
            this.btn_AgregarFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AgregarFoto.Font = new System.Drawing.Font("Glacial Indifference", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AgregarFoto.ForeColor = System.Drawing.Color.White;
            this.btn_AgregarFoto.Location = new System.Drawing.Point(84, 219);
            this.btn_AgregarFoto.Name = "btn_AgregarFoto";
            this.btn_AgregarFoto.Size = new System.Drawing.Size(140, 35);
            this.btn_AgregarFoto.TabIndex = 34;
            this.btn_AgregarFoto.Text = "+ Agregar una foto";
            this.btn_AgregarFoto.TextColor = System.Drawing.Color.White;
            this.btn_AgregarFoto.UseVisualStyleBackColor = false;
            this.btn_AgregarFoto.Click += new System.EventHandler(this.btn_AgregarFoto_Click);
            // 
            // pic_BorrarImagen
            // 
            this.pic_BorrarImagen.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.bin32;
            this.pic_BorrarImagen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_BorrarImagen.Location = new System.Drawing.Point(190, 298);
            this.pic_BorrarImagen.Name = "pic_BorrarImagen";
            this.pic_BorrarImagen.Size = new System.Drawing.Size(16, 16);
            this.pic_BorrarImagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_BorrarImagen.TabIndex = 32;
            this.pic_BorrarImagen.TabStop = false;
            this.pic_BorrarImagen.Visible = false;
            this.pic_BorrarImagen.Click += new System.EventHandler(this.pic_BorrarImagen_Click);
            // 
            // pic_Logo1
            // 
            this.pic_Logo1.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.Header;
            this.pic_Logo1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_Logo1.Location = new System.Drawing.Point(10, 3);
            this.pic_Logo1.Name = "pic_Logo1";
            this.pic_Logo1.Size = new System.Drawing.Size(300, 94);
            this.pic_Logo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Logo1.TabIndex = 31;
            this.pic_Logo1.TabStop = false;
            // 
            // lbl_CostoProductos
            // 
            this.lbl_CostoProductos.AutoSize = true;
            this.lbl_CostoProductos.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CostoProductos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CostoProductos.Location = new System.Drawing.Point(13, 337);
            this.lbl_CostoProductos.Name = "lbl_CostoProductos";
            this.lbl_CostoProductos.Size = new System.Drawing.Size(145, 28);
            this.lbl_CostoProductos.TabIndex = 29;
            this.lbl_CostoProductos.Text = "Costo Productos:";
            // 
            // pic_ImagenAdjunta
            // 
            this.pic_ImagenAdjunta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_ImagenAdjunta.Location = new System.Drawing.Point(121, 264);
            this.pic_ImagenAdjunta.Name = "pic_ImagenAdjunta";
            this.pic_ImagenAdjunta.Size = new System.Drawing.Size(60, 60);
            this.pic_ImagenAdjunta.TabIndex = 27;
            this.pic_ImagenAdjunta.TabStop = false;
            // 
            // btn_Seguir
            // 
            this.btn_Seguir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Seguir.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Seguir.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Seguir.BorderRadius = 20;
            this.btn_Seguir.BorderSize = 0;
            this.btn_Seguir.FlatAppearance.BorderSize = 0;
            this.btn_Seguir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Seguir.Font = new System.Drawing.Font("Glacial Indifference", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Seguir.ForeColor = System.Drawing.Color.White;
            this.btn_Seguir.Location = new System.Drawing.Point(182, 506);
            this.btn_Seguir.Name = "btn_Seguir";
            this.btn_Seguir.Size = new System.Drawing.Size(117, 40);
            this.btn_Seguir.TabIndex = 26;
            this.btn_Seguir.Text = "Continuar";
            this.btn_Seguir.TextColor = System.Drawing.Color.White;
            this.btn_Seguir.UseVisualStyleBackColor = false;
            this.btn_Seguir.Click += new System.EventHandler(this.btn_Seguir_Click);
            // 
            // op_IngresarFechaHora
            // 
            this.op_IngresarFechaHora.AutoSize = true;
            this.op_IngresarFechaHora.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(190)))), ((int)(((byte)(221)))));
            this.op_IngresarFechaHora.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(190)))), ((int)(((byte)(221)))));
            this.op_IngresarFechaHora.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.op_IngresarFechaHora.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.op_IngresarFechaHora.Location = new System.Drawing.Point(18, 460);
            this.op_IngresarFechaHora.Name = "op_IngresarFechaHora";
            this.op_IngresarFechaHora.Size = new System.Drawing.Size(157, 26);
            this.op_IngresarFechaHora.TabIndex = 24;
            this.op_IngresarFechaHora.TabStop = true;
            this.op_IngresarFechaHora.Text = "Ingresar fecha y hora.";
            this.op_IngresarFechaHora.UseVisualStyleBackColor = true;
            this.op_IngresarFechaHora.CheckedChanged += new System.EventHandler(this.op_IngresarFechaHora_CheckedChanged);
            // 
            // op_LoAntesPosible
            // 
            this.op_LoAntesPosible.AutoSize = true;
            this.op_LoAntesPosible.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.op_LoAntesPosible.FlatAppearance.CheckedBackColor = System.Drawing.Color.Black;
            this.op_LoAntesPosible.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.op_LoAntesPosible.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.op_LoAntesPosible.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.op_LoAntesPosible.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.op_LoAntesPosible.Location = new System.Drawing.Point(18, 436);
            this.op_LoAntesPosible.Name = "op_LoAntesPosible";
            this.op_LoAntesPosible.Size = new System.Drawing.Size(126, 26);
            this.op_LoAntesPosible.TabIndex = 23;
            this.op_LoAntesPosible.TabStop = true;
            this.op_LoAntesPosible.Text = "Lo antes posible.";
            this.op_LoAntesPosible.UseVisualStyleBackColor = true;
            this.op_LoAntesPosible.CheckedChanged += new System.EventHandler(this.op_LoAntesPosible_CheckedChanged);
            // 
            // lbl_Cuando
            // 
            this.lbl_Cuando.AutoSize = true;
            this.lbl_Cuando.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cuando.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_Cuando.Location = new System.Drawing.Point(13, 405);
            this.lbl_Cuando.Name = "lbl_Cuando";
            this.lbl_Cuando.Size = new System.Drawing.Size(177, 28);
            this.lbl_Cuando.TabIndex = 22;
            this.lbl_Cuando.Text = "Seleccionar entrega:";
            // 
            // lbl_PedidoPersonalizado
            // 
            this.lbl_PedidoPersonalizado.AutoSize = true;
            this.lbl_PedidoPersonalizado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_PedidoPersonalizado.ForeColor = System.Drawing.Color.Black;
            this.lbl_PedidoPersonalizado.Location = new System.Drawing.Point(15, 74);
            this.lbl_PedidoPersonalizado.Name = "lbl_PedidoPersonalizado";
            this.lbl_PedidoPersonalizado.Size = new System.Drawing.Size(247, 20);
            this.lbl_PedidoPersonalizado.TabIndex = 18;
            this.lbl_PedidoPersonalizado.Text = "Realizar pedido de lo que sea";
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.lineaVertical;
            this.pictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox17.Location = new System.Drawing.Point(23, 120);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(2, 20);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox17.TabIndex = 50;
            this.pictureBox17.TabStop = false;
            // 
            // txt_DirComercio
            // 
            this.txt_DirComercio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_DirComercio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_DirComercio.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_DirComercio.Location = new System.Drawing.Point(25, 74);
            this.txt_DirComercio.MaxLength = 240;
            this.txt_DirComercio.Name = "txt_DirComercio";
            this.txt_DirComercio.Size = new System.Drawing.Size(260, 15);
            this.txt_DirComercio.TabIndex = 8;
            this.txt_DirComercio.Text = "Ingrese el nombre y número de la calle aquí.";
            this.txt_DirComercio.Click += new System.EventHandler(this.txt_DirComercio_Click);
            // 
            // lbl_DirComercio
            // 
            this.lbl_DirComercio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_DirComercio.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DirComercio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_DirComercio.Location = new System.Drawing.Point(13, 51);
            this.lbl_DirComercio.Name = "lbl_DirComercio";
            this.lbl_DirComercio.Size = new System.Drawing.Size(106, 20);
            this.lbl_DirComercio.TabIndex = 7;
            this.lbl_DirComercio.Text = "Calle y número";
            // 
            // lbl_Direccion
            // 
            this.lbl_Direccion.AutoSize = true;
            this.lbl_Direccion.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Direccion.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Direccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_Direccion.Location = new System.Drawing.Point(13, 27);
            this.lbl_Direccion.Name = "lbl_Direccion";
            this.lbl_Direccion.Size = new System.Drawing.Size(221, 28);
            this.lbl_Direccion.TabIndex = 5;
            this.lbl_Direccion.Text = "Dirección del Comercio";
            // 
            // cmb_CiudadComercio
            // 
            this.cmb_CiudadComercio.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_CiudadComercio.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmb_CiudadComercio.BackColor = System.Drawing.SystemColors.Window;
            this.cmb_CiudadComercio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cmb_CiudadComercio.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cmb_CiudadComercio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_CiudadComercio.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.cmb_CiudadComercio.FormattingEnabled = true;
            this.cmb_CiudadComercio.Location = new System.Drawing.Point(24, 119);
            this.cmb_CiudadComercio.Name = "cmb_CiudadComercio";
            this.cmb_CiudadComercio.Size = new System.Drawing.Size(261, 19);
            this.cmb_CiudadComercio.TabIndex = 11;
            this.cmb_CiudadComercio.Validating += new System.ComponentModel.CancelEventHandler(this.cmb_CiudadComercio_Validating);
            // 
            // lbl_CiudadComercio
            // 
            this.lbl_CiudadComercio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CiudadComercio.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CiudadComercio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CiudadComercio.Location = new System.Drawing.Point(13, 99);
            this.lbl_CiudadComercio.Name = "lbl_CiudadComercio";
            this.lbl_CiudadComercio.Size = new System.Drawing.Size(58, 18);
            this.lbl_CiudadComercio.TabIndex = 12;
            this.lbl_CiudadComercio.Text = "Ciudad";
            // 
            // lbl_CaracteresRef
            // 
            this.lbl_CaracteresRef.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CaracteresRef.Font = new System.Drawing.Font("Poppins", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CaracteresRef.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CaracteresRef.Location = new System.Drawing.Point(235, 229);
            this.lbl_CaracteresRef.Name = "lbl_CaracteresRef";
            this.lbl_CaracteresRef.Size = new System.Drawing.Size(56, 15);
            this.lbl_CaracteresRef.TabIndex = 16;
            this.lbl_CaracteresRef.Text = "0/240";
            this.lbl_CaracteresRef.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txt_ReferenciaComercio
            // 
            this.txt_ReferenciaComercio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_ReferenciaComercio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_ReferenciaComercio.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_ReferenciaComercio.Location = new System.Drawing.Point(23, 169);
            this.txt_ReferenciaComercio.MaxLength = 240;
            this.txt_ReferenciaComercio.Multiline = true;
            this.txt_ReferenciaComercio.Name = "txt_ReferenciaComercio";
            this.txt_ReferenciaComercio.Size = new System.Drawing.Size(261, 55);
            this.txt_ReferenciaComercio.TabIndex = 15;
            this.txt_ReferenciaComercio.Text = "Indicaciones de referencia.";
            this.txt_ReferenciaComercio.Click += new System.EventHandler(this.txt_ReferenciaComercio_Click);
            this.txt_ReferenciaComercio.TextChanged += new System.EventHandler(this.txt_ReferenciaComercio_TextChanged);
            // 
            // lbl_ReferenciaComercio
            // 
            this.lbl_ReferenciaComercio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ReferenciaComercio.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ReferenciaComercio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_ReferenciaComercio.Location = new System.Drawing.Point(13, 145);
            this.lbl_ReferenciaComercio.Name = "lbl_ReferenciaComercio";
            this.lbl_ReferenciaComercio.Size = new System.Drawing.Size(153, 19);
            this.lbl_ReferenciaComercio.TabIndex = 17;
            this.lbl_ReferenciaComercio.Text = "Referencia (opcional)";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_Total.ForeColor = System.Drawing.Color.Black;
            this.lbl_Total.Location = new System.Drawing.Point(3, 18);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(116, 20);
            this.lbl_Total.TabIndex = 19;
            this.lbl_Total.Text = "Total a Pagar";
            // 
            // txt_CostoTotal
            // 
            this.txt_CostoTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.txt_CostoTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CostoTotal.Font = new System.Drawing.Font("Poppins Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CostoTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.txt_CostoTotal.Location = new System.Drawing.Point(7, 130);
            this.txt_CostoTotal.Multiline = true;
            this.txt_CostoTotal.Name = "txt_CostoTotal";
            this.txt_CostoTotal.Size = new System.Drawing.Size(129, 18);
            this.txt_CostoTotal.TabIndex = 20;
            this.txt_CostoTotal.Text = "$0,00";
            this.txt_CostoTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // pnl_Ruta
            // 
            this.pnl_Ruta.AutoScroll = true;
            this.pnl_Ruta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.pnl_Ruta.Controls.Add(this.pictureBox19);
            this.pnl_Ruta.Controls.Add(this.pictureBox20);
            this.pnl_Ruta.Controls.Add(this.pictureBox18);
            this.pnl_Ruta.Controls.Add(this.pictureBox17);
            this.pnl_Ruta.Controls.Add(this.pictureBox16);
            this.pnl_Ruta.Controls.Add(this.pictureBox13);
            this.pnl_Ruta.Controls.Add(this.cmb_CiudadDomicilio);
            this.pnl_Ruta.Controls.Add(this.pictureBox10);
            this.pnl_Ruta.Controls.Add(this.lbl_CaracteresRef);
            this.pnl_Ruta.Controls.Add(this.lbl_ReferenciaComercio);
            this.pnl_Ruta.Controls.Add(this.lbl_RefDomicilio);
            this.pnl_Ruta.Controls.Add(this.lbl_CaracteresRef2);
            this.pnl_Ruta.Controls.Add(this.lbl_DirDomicilio);
            this.pnl_Ruta.Controls.Add(this.txt_RefDomicilio);
            this.pnl_Ruta.Controls.Add(this.pictureBox9);
            this.pnl_Ruta.Controls.Add(this.txt_ReferenciaComercio);
            this.pnl_Ruta.Controls.Add(this.pictureBox8);
            this.pnl_Ruta.Controls.Add(this.txt_DirDomicilio);
            this.pnl_Ruta.Controls.Add(this.pictureBox7);
            this.pnl_Ruta.Controls.Add(this.lbl_DirComercio);
            this.pnl_Ruta.Controls.Add(this.txt_DirComercio);
            this.pnl_Ruta.Controls.Add(this.pictureBox6);
            this.pnl_Ruta.Controls.Add(this.cmb_CiudadComercio);
            this.pnl_Ruta.Controls.Add(this.pictureBox5);
            this.pnl_Ruta.Controls.Add(this.lbl_Fin);
            this.pnl_Ruta.Controls.Add(this.pic_Mapa2);
            this.pnl_Ruta.Controls.Add(this.lbl_Direccion);
            this.pnl_Ruta.Controls.Add(this.lbl_CiudadDomicilio);
            this.pnl_Ruta.Controls.Add(this.pic_Mapa);
            this.pnl_Ruta.Controls.Add(this.lbl_CiudadComercio);
            this.pnl_Ruta.Controls.Add(this.lbl_Domicilio);
            this.pnl_Ruta.Location = new System.Drawing.Point(0, 3);
            this.pnl_Ruta.Name = "pnl_Ruta";
            this.pnl_Ruta.Size = new System.Drawing.Size(317, 391);
            this.pnl_Ruta.TabIndex = 22;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.lineaVertical;
            this.pictureBox19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox19.Location = new System.Drawing.Point(283, 523);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(2, 20);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox19.TabIndex = 53;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.lineaVertical;
            this.pictureBox20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox20.Location = new System.Drawing.Point(23, 523);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(2, 20);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox20.TabIndex = 52;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.lineaVertical;
            this.pictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox18.Location = new System.Drawing.Point(283, 120);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(2, 20);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox18.TabIndex = 51;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.lineaHorizontal;
            this.pictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox16.Location = new System.Drawing.Point(24, 522);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(261, 3);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox16.TabIndex = 41;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.lineaHorizontal;
            this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox13.Location = new System.Drawing.Point(24, 119);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(261, 3);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox13.TabIndex = 38;
            this.pictureBox13.TabStop = false;
            // 
            // cmb_CiudadDomicilio
            // 
            this.cmb_CiudadDomicilio.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_CiudadDomicilio.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmb_CiudadDomicilio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cmb_CiudadDomicilio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_CiudadDomicilio.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.cmb_CiudadDomicilio.FormattingEnabled = true;
            this.cmb_CiudadDomicilio.Location = new System.Drawing.Point(24, 522);
            this.cmb_CiudadDomicilio.Name = "cmb_CiudadDomicilio";
            this.cmb_CiudadDomicilio.Size = new System.Drawing.Size(261, 19);
            this.cmb_CiudadDomicilio.TabIndex = 27;
            this.cmb_CiudadDomicilio.Validating += new System.ComponentModel.CancelEventHandler(this.cmb_CiudadDomicilio_Validating);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox10.Location = new System.Drawing.Point(17, 520);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(274, 26);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox10.TabIndex = 40;
            this.pictureBox10.TabStop = false;
            // 
            // lbl_RefDomicilio
            // 
            this.lbl_RefDomicilio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_RefDomicilio.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RefDomicilio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_RefDomicilio.Location = new System.Drawing.Point(13, 549);
            this.lbl_RefDomicilio.Name = "lbl_RefDomicilio";
            this.lbl_RefDomicilio.Size = new System.Drawing.Size(189, 20);
            this.lbl_RefDomicilio.TabIndex = 31;
            this.lbl_RefDomicilio.Text = "Referencia (opcional)";
            // 
            // lbl_CaracteresRef2
            // 
            this.lbl_CaracteresRef2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CaracteresRef2.Font = new System.Drawing.Font("Poppins", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CaracteresRef2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CaracteresRef2.Location = new System.Drawing.Point(237, 639);
            this.lbl_CaracteresRef2.Name = "lbl_CaracteresRef2";
            this.lbl_CaracteresRef2.Size = new System.Drawing.Size(54, 16);
            this.lbl_CaracteresRef2.TabIndex = 30;
            this.lbl_CaracteresRef2.Text = "0/240";
            this.lbl_CaracteresRef2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_DirDomicilio
            // 
            this.lbl_DirDomicilio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_DirDomicilio.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DirDomicilio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_DirDomicilio.Location = new System.Drawing.Point(13, 447);
            this.lbl_DirDomicilio.Name = "lbl_DirDomicilio";
            this.lbl_DirDomicilio.Size = new System.Drawing.Size(135, 19);
            this.lbl_DirDomicilio.TabIndex = 23;
            this.lbl_DirDomicilio.Text = "Calle y número";
            // 
            // txt_RefDomicilio
            // 
            this.txt_RefDomicilio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_RefDomicilio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_RefDomicilio.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_RefDomicilio.Location = new System.Drawing.Point(23, 575);
            this.txt_RefDomicilio.MaxLength = 240;
            this.txt_RefDomicilio.Multiline = true;
            this.txt_RefDomicilio.Name = "txt_RefDomicilio";
            this.txt_RefDomicilio.Size = new System.Drawing.Size(262, 55);
            this.txt_RefDomicilio.TabIndex = 29;
            this.txt_RefDomicilio.Text = "Indicaciones de referencia.";
            this.txt_RefDomicilio.Click += new System.EventHandler(this.txt_RefDomicilio_Click);
            this.txt_RefDomicilio.TextChanged += new System.EventHandler(this.txt_RefDomicilio_TextChanged);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text63;
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(17, 566);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(274, 74);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox9.TabIndex = 39;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text63;
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Location = new System.Drawing.Point(17, 162);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(274, 70);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox8.TabIndex = 37;
            this.pictureBox8.TabStop = false;
            // 
            // txt_DirDomicilio
            // 
            this.txt_DirDomicilio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_DirDomicilio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_DirDomicilio.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_DirDomicilio.Location = new System.Drawing.Point(25, 472);
            this.txt_DirDomicilio.MaxLength = 240;
            this.txt_DirDomicilio.Name = "txt_DirDomicilio";
            this.txt_DirDomicilio.Size = new System.Drawing.Size(260, 15);
            this.txt_DirDomicilio.TabIndex = 24;
            this.txt_DirDomicilio.Text = "Ingrese el nombre y número de la calle aquí.";
            this.txt_DirDomicilio.Click += new System.EventHandler(this.txt_DirDomicilio_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(17, 465);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(274, 35);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox7.TabIndex = 38;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(17, 63);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(274, 40);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox6.TabIndex = 37;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(17, 117);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(274, 27);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 37;
            this.pictureBox5.TabStop = false;
            // 
            // lbl_Fin
            // 
            this.lbl_Fin.AutoSize = true;
            this.lbl_Fin.Location = new System.Drawing.Point(148, 834);
            this.lbl_Fin.Name = "lbl_Fin";
            this.lbl_Fin.Size = new System.Drawing.Size(0, 13);
            this.lbl_Fin.TabIndex = 35;
            // 
            // pic_Mapa2
            // 
            this.pic_Mapa2.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.mapa_Co;
            this.pic_Mapa2.Location = new System.Drawing.Point(16, 662);
            this.pic_Mapa2.Name = "pic_Mapa2";
            this.pic_Mapa2.Size = new System.Drawing.Size(274, 164);
            this.pic_Mapa2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Mapa2.TabIndex = 34;
            this.pic_Mapa2.TabStop = false;
            this.pic_Mapa2.Click += new System.EventHandler(this.pic_Mapa2_Click);
            // 
            // lbl_CiudadDomicilio
            // 
            this.lbl_CiudadDomicilio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CiudadDomicilio.Font = new System.Drawing.Font("Poppins", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CiudadDomicilio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CiudadDomicilio.Location = new System.Drawing.Point(13, 503);
            this.lbl_CiudadDomicilio.Name = "lbl_CiudadDomicilio";
            this.lbl_CiudadDomicilio.Size = new System.Drawing.Size(71, 18);
            this.lbl_CiudadDomicilio.TabIndex = 28;
            this.lbl_CiudadDomicilio.Text = "Ciudad";
            // 
            // pic_Mapa
            // 
            this.pic_Mapa.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.mapa_Co1;
            this.pic_Mapa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_Mapa.Location = new System.Drawing.Point(17, 247);
            this.pic_Mapa.Name = "pic_Mapa";
            this.pic_Mapa.Size = new System.Drawing.Size(274, 164);
            this.pic_Mapa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Mapa.TabIndex = 33;
            this.pic_Mapa.TabStop = false;
            this.pic_Mapa.Click += new System.EventHandler(this.pic_Mapa_Click);
            // 
            // lbl_Domicilio
            // 
            this.lbl_Domicilio.AutoSize = true;
            this.lbl_Domicilio.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Domicilio.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Domicilio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_Domicilio.Location = new System.Drawing.Point(10, 416);
            this.lbl_Domicilio.Name = "lbl_Domicilio";
            this.lbl_Domicilio.Size = new System.Drawing.Size(217, 28);
            this.lbl_Domicilio.TabIndex = 22;
            this.lbl_Domicilio.Text = "Dirección del Domicilio";
            // 
            // lbl_Ingresar
            // 
            this.lbl_Ingresar.AutoSize = true;
            this.lbl_Ingresar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_Ingresar.ForeColor = System.Drawing.Color.Black;
            this.lbl_Ingresar.Location = new System.Drawing.Point(90, 74);
            this.lbl_Ingresar.Name = "lbl_Ingresar";
            this.lbl_Ingresar.Size = new System.Drawing.Size(113, 20);
            this.lbl_Ingresar.TabIndex = 18;
            this.lbl_Ingresar.Text = "Ingresar ruta";
            this.lbl_Ingresar.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.panel3.Controls.Add(this.btn_Atras3);
            this.panel3.Controls.Add(this.pic_Logo3);
            this.panel3.Controls.Add(this.btn_Confirmar);
            this.panel3.Controls.Add(this.pnl_Tarjeta);
            this.panel3.Controls.Add(this.pnl_Efectivo);
            this.panel3.Location = new System.Drawing.Point(686, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(320, 561);
            this.panel3.TabIndex = 23;
            // 
            // btn_Atras3
            // 
            this.btn_Atras3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(166)))), ((int)(((byte)(202)))));
            this.btn_Atras3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(166)))), ((int)(((byte)(202)))));
            this.btn_Atras3.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Atras3.BorderRadius = 20;
            this.btn_Atras3.BorderSize = 0;
            this.btn_Atras3.FlatAppearance.BorderSize = 0;
            this.btn_Atras3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Atras3.Font = new System.Drawing.Font("Glacial Indifference", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Atras3.ForeColor = System.Drawing.Color.White;
            this.btn_Atras3.Location = new System.Drawing.Point(17, 506);
            this.btn_Atras3.Name = "btn_Atras3";
            this.btn_Atras3.Size = new System.Drawing.Size(117, 40);
            this.btn_Atras3.TabIndex = 34;
            this.btn_Atras3.Text = "Atrás";
            this.btn_Atras3.TextColor = System.Drawing.Color.White;
            this.btn_Atras3.UseVisualStyleBackColor = false;
            this.btn_Atras3.Click += new System.EventHandler(this.btn_Atras3_Click);
            // 
            // pic_Logo3
            // 
            this.pic_Logo3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pic_Logo3.BackgroundImage")));
            this.pic_Logo3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_Logo3.Location = new System.Drawing.Point(10, 3);
            this.pic_Logo3.Name = "pic_Logo3";
            this.pic_Logo3.Size = new System.Drawing.Size(300, 94);
            this.pic_Logo3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Logo3.TabIndex = 33;
            this.pic_Logo3.TabStop = false;
            // 
            // btn_Confirmar
            // 
            this.btn_Confirmar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Confirmar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Confirmar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Confirmar.BorderRadius = 20;
            this.btn_Confirmar.BorderSize = 0;
            this.btn_Confirmar.FlatAppearance.BorderSize = 0;
            this.btn_Confirmar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Confirmar.Font = new System.Drawing.Font("Glacial Indifference", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Confirmar.ForeColor = System.Drawing.Color.White;
            this.btn_Confirmar.Location = new System.Drawing.Point(182, 506);
            this.btn_Confirmar.Name = "btn_Confirmar";
            this.btn_Confirmar.Size = new System.Drawing.Size(117, 40);
            this.btn_Confirmar.TabIndex = 35;
            this.btn_Confirmar.Text = "Confirmar";
            this.btn_Confirmar.TextColor = System.Drawing.Color.White;
            this.btn_Confirmar.UseVisualStyleBackColor = false;
            this.btn_Confirmar.Click += new System.EventHandler(this.btn_Confirmar_Click);
            // 
            // pnl_Tarjeta
            // 
            this.pnl_Tarjeta.Controls.Add(this.txt_NombreApellidoTitular);
            this.pnl_Tarjeta.Controls.Add(this.pictureBox15);
            this.pnl_Tarjeta.Controls.Add(this.txt_NumeroTarjeta);
            this.pnl_Tarjeta.Controls.Add(this.pictureBox14);
            this.pnl_Tarjeta.Controls.Add(this.txt_CodigoSeguridad);
            this.pnl_Tarjeta.Controls.Add(this.pictureBox12);
            this.pnl_Tarjeta.Controls.Add(this.txt_Vencimiento);
            this.pnl_Tarjeta.Controls.Add(this.pictureBox11);
            this.pnl_Tarjeta.Controls.Add(this.pic_VisaGris);
            this.pnl_Tarjeta.Controls.Add(this.pic_Visa);
            this.pnl_Tarjeta.Controls.Add(this.lbl_CVC);
            this.pnl_Tarjeta.Controls.Add(this.lbl_NroTarjeta);
            this.pnl_Tarjeta.Controls.Add(this.lbl_FechaVencimiento);
            this.pnl_Tarjeta.Controls.Add(this.label4);
            this.pnl_Tarjeta.Controls.Add(this.lblTarjeta);
            this.pnl_Tarjeta.Location = new System.Drawing.Point(23, 284);
            this.pnl_Tarjeta.Name = "pnl_Tarjeta";
            this.pnl_Tarjeta.Size = new System.Drawing.Size(284, 216);
            this.pnl_Tarjeta.TabIndex = 34;
            // 
            // txt_NombreApellidoTitular
            // 
            this.txt_NombreApellidoTitular.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_NombreApellidoTitular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_NombreApellidoTitular.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_NombreApellidoTitular.Location = new System.Drawing.Point(16, 102);
            this.txt_NombreApellidoTitular.MaxLength = 240;
            this.txt_NombreApellidoTitular.Multiline = true;
            this.txt_NombreApellidoTitular.Name = "txt_NombreApellidoTitular";
            this.txt_NombreApellidoTitular.Size = new System.Drawing.Size(255, 16);
            this.txt_NombreApellidoTitular.TabIndex = 37;
            this.txt_NombreApellidoTitular.Text = "Ingrese el nombre aquí.";
            this.txt_NombreApellidoTitular.Click += new System.EventHandler(this.txt_NombreApellidoTitular_Click);
            this.txt_NombreApellidoTitular.EnabledChanged += new System.EventHandler(this.txt_NombreApellidoTitular_EnabledChanged);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox15.Location = new System.Drawing.Point(7, 96);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(271, 30);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox15.TabIndex = 51;
            this.pictureBox15.TabStop = false;
            // 
            // txt_NumeroTarjeta
            // 
            this.txt_NumeroTarjeta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_NumeroTarjeta.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_NumeroTarjeta.Location = new System.Drawing.Point(14, 58);
            this.txt_NumeroTarjeta.Mask = "9999 9999 9999 9999";
            this.txt_NumeroTarjeta.Name = "txt_NumeroTarjeta";
            this.txt_NumeroTarjeta.Size = new System.Drawing.Size(255, 13);
            this.txt_NumeroTarjeta.TabIndex = 43;
            this.txt_NumeroTarjeta.EnabledChanged += new System.EventHandler(this.txt_NumeroTarjeta_EnabledChanged);
            this.txt_NumeroTarjeta.TextChanged += new System.EventHandler(this.txt_NumeroTarjeta_TextChanged);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.ext;
            this.pictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox14.Location = new System.Drawing.Point(6, 50);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(271, 30);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox14.TabIndex = 50;
            this.pictureBox14.TabStop = false;
            // 
            // txt_CodigoSeguridad
            // 
            this.txt_CodigoSeguridad.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CodigoSeguridad.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_CodigoSeguridad.Location = new System.Drawing.Point(155, 149);
            this.txt_CodigoSeguridad.Mask = "999";
            this.txt_CodigoSeguridad.Name = "txt_CodigoSeguridad";
            this.txt_CodigoSeguridad.Size = new System.Drawing.Size(115, 13);
            this.txt_CodigoSeguridad.TabIndex = 46;
            this.txt_CodigoSeguridad.EnabledChanged += new System.EventHandler(this.txt_CodigoSeguridad_EnabledChanged);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text20tarjeta;
            this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox12.Location = new System.Drawing.Point(148, 143);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(129, 26);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox12.TabIndex = 48;
            this.pictureBox12.TabStop = false;
            // 
            // txt_Vencimiento
            // 
            this.txt_Vencimiento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_Vencimiento.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_Vencimiento.Location = new System.Drawing.Point(13, 149);
            this.txt_Vencimiento.Mask = "99/9999";
            this.txt_Vencimiento.Name = "txt_Vencimiento";
            this.txt_Vencimiento.Size = new System.Drawing.Size(123, 13);
            this.txt_Vencimiento.TabIndex = 47;
            this.txt_Vencimiento.EnabledChanged += new System.EventHandler(this.txt_Vencimiento_EnabledChanged);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text20tarjeta;
            this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox11.Location = new System.Drawing.Point(6, 143);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(136, 26);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox11.TabIndex = 38;
            this.pictureBox11.TabStop = false;
            // 
            // pic_VisaGris
            // 
            this.pic_VisaGris.Image = ((System.Drawing.Image)(resources.GetObject("pic_VisaGris.Image")));
            this.pic_VisaGris.Location = new System.Drawing.Point(7, 166);
            this.pic_VisaGris.Name = "pic_VisaGris";
            this.pic_VisaGris.Size = new System.Drawing.Size(50, 50);
            this.pic_VisaGris.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_VisaGris.TabIndex = 45;
            this.pic_VisaGris.TabStop = false;
            // 
            // pic_Visa
            // 
            this.pic_Visa.Image = ((System.Drawing.Image)(resources.GetObject("pic_Visa.Image")));
            this.pic_Visa.Location = new System.Drawing.Point(7, 166);
            this.pic_Visa.Name = "pic_Visa";
            this.pic_Visa.Size = new System.Drawing.Size(50, 50);
            this.pic_Visa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_Visa.TabIndex = 44;
            this.pic_Visa.TabStop = false;
            this.pic_Visa.Visible = false;
            // 
            // lbl_CVC
            // 
            this.lbl_CVC.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CVC.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CVC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_CVC.Location = new System.Drawing.Point(145, 125);
            this.lbl_CVC.Name = "lbl_CVC";
            this.lbl_CVC.Size = new System.Drawing.Size(136, 20);
            this.lbl_CVC.TabIndex = 42;
            this.lbl_CVC.Text = "Código de Seguridad";
            // 
            // lbl_NroTarjeta
            // 
            this.lbl_NroTarjeta.BackColor = System.Drawing.Color.Transparent;
            this.lbl_NroTarjeta.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NroTarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_NroTarjeta.Location = new System.Drawing.Point(4, 34);
            this.lbl_NroTarjeta.Name = "lbl_NroTarjeta";
            this.lbl_NroTarjeta.Size = new System.Drawing.Size(134, 16);
            this.lbl_NroTarjeta.TabIndex = 34;
            this.lbl_NroTarjeta.Text = "Número de la Tarjeta";
            // 
            // lbl_FechaVencimiento
            // 
            this.lbl_FechaVencimiento.BackColor = System.Drawing.Color.Transparent;
            this.lbl_FechaVencimiento.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FechaVencimiento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_FechaVencimiento.Location = new System.Drawing.Point(4, 125);
            this.lbl_FechaVencimiento.Name = "lbl_FechaVencimiento";
            this.lbl_FechaVencimiento.Size = new System.Drawing.Size(151, 21);
            this.lbl_FechaVencimiento.TabIndex = 39;
            this.lbl_FechaVencimiento.Text = "Fecha de Vencimiento";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.label4.Location = new System.Drawing.Point(4, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 19);
            this.label4.TabIndex = 36;
            this.label4.Text = "Nombre y Apellido del Titular";
            // 
            // lblTarjeta
            // 
            this.lblTarjeta.AutoSize = true;
            this.lblTarjeta.BackColor = System.Drawing.Color.Transparent;
            this.lblTarjeta.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lblTarjeta.Location = new System.Drawing.Point(4, 9);
            this.lblTarjeta.Name = "lblTarjeta";
            this.lblTarjeta.Size = new System.Drawing.Size(263, 28);
            this.lblTarjeta.TabIndex = 32;
            this.lblTarjeta.Text = "Ingresar datos de la Tarjeta";
            // 
            // pnl_Efectivo
            // 
            this.pnl_Efectivo.Controls.Add(this.txt_EfectivoAPagar);
            this.pnl_Efectivo.Controls.Add(this.pic_EfectivoPagar);
            this.pnl_Efectivo.Controls.Add(this.label1);
            this.pnl_Efectivo.Controls.Add(this.lbl_EnTotal);
            this.pnl_Efectivo.Controls.Add(this.lbl_EnEnvio);
            this.pnl_Efectivo.Controls.Add(this.lbl_EnProductos);
            this.pnl_Efectivo.Controls.Add(this.txt_TotalProductos);
            this.pnl_Efectivo.Controls.Add(this.txt_CostoEnvio);
            this.pnl_Efectivo.Controls.Add(this.op_Tarjeta);
            this.pnl_Efectivo.Controls.Add(this.txt_CostoTotal);
            this.pnl_Efectivo.Controls.Add(this.lbl_Total);
            this.pnl_Efectivo.Controls.Add(this.label12);
            this.pnl_Efectivo.Controls.Add(this.op_Efectivo);
            this.pnl_Efectivo.Location = new System.Drawing.Point(23, 56);
            this.pnl_Efectivo.Name = "pnl_Efectivo";
            this.pnl_Efectivo.Size = new System.Drawing.Size(284, 441);
            this.pnl_Efectivo.TabIndex = 22;
            // 
            // txt_EfectivoAPagar
            // 
            this.txt_EfectivoAPagar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_EfectivoAPagar.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_EfectivoAPagar.Location = new System.Drawing.Point(87, 190);
            this.txt_EfectivoAPagar.Name = "txt_EfectivoAPagar";
            this.txt_EfectivoAPagar.Size = new System.Drawing.Size(103, 13);
            this.txt_EfectivoAPagar.TabIndex = 34;
            this.txt_EfectivoAPagar.Text = "$___.___.___,__";
            this.txt_EfectivoAPagar.Click += new System.EventHandler(this.txt_EfectivoAPagar_Click);
            this.txt_EfectivoAPagar.TextChanged += new System.EventHandler(this.txt_EfectivoAPagar_TextChanged);
            this.txt_EfectivoAPagar.Leave += new System.EventHandler(this.txt_EfectivoAPagar_Leave);
            // 
            // pic_EfectivoPagar
            // 
            this.pic_EfectivoPagar.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.text20tarjeta;
            this.pic_EfectivoPagar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_EfectivoPagar.Location = new System.Drawing.Point(80, 184);
            this.pic_EfectivoPagar.Name = "pic_EfectivoPagar";
            this.pic_EfectivoPagar.Size = new System.Drawing.Size(116, 26);
            this.pic_EfectivoPagar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_EfectivoPagar.TabIndex = 37;
            this.pic_EfectivoPagar.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.label1.Location = new System.Drawing.Point(1, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 22);
            this.label1.TabIndex = 35;
            this.label1.Text = "Total a pagar";
            // 
            // lbl_EnTotal
            // 
            this.lbl_EnTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.lbl_EnTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_EnTotal.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EnTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_EnTotal.Location = new System.Drawing.Point(139, 130);
            this.lbl_EnTotal.Multiline = true;
            this.lbl_EnTotal.Name = "lbl_EnTotal";
            this.lbl_EnTotal.Size = new System.Drawing.Size(100, 18);
            this.lbl_EnTotal.TabIndex = 31;
            this.lbl_EnTotal.Text = "en total.";
            // 
            // lbl_EnEnvio
            // 
            this.lbl_EnEnvio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.lbl_EnEnvio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_EnEnvio.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EnEnvio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_EnEnvio.Location = new System.Drawing.Point(139, 106);
            this.lbl_EnEnvio.Multiline = true;
            this.lbl_EnEnvio.Name = "lbl_EnEnvio";
            this.lbl_EnEnvio.Size = new System.Drawing.Size(100, 18);
            this.lbl_EnEnvio.TabIndex = 30;
            this.lbl_EnEnvio.Text = "en envío.";
            // 
            // lbl_EnProductos
            // 
            this.lbl_EnProductos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.lbl_EnProductos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_EnProductos.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EnProductos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.lbl_EnProductos.Location = new System.Drawing.Point(139, 82);
            this.lbl_EnProductos.Multiline = true;
            this.lbl_EnProductos.Name = "lbl_EnProductos";
            this.lbl_EnProductos.Size = new System.Drawing.Size(121, 23);
            this.lbl_EnProductos.TabIndex = 29;
            this.lbl_EnProductos.Text = "en productos.";
            // 
            // txt_TotalProductos
            // 
            this.txt_TotalProductos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.txt_TotalProductos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_TotalProductos.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TotalProductos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.txt_TotalProductos.Location = new System.Drawing.Point(6, 83);
            this.txt_TotalProductos.Multiline = true;
            this.txt_TotalProductos.Name = "txt_TotalProductos";
            this.txt_TotalProductos.Size = new System.Drawing.Size(130, 18);
            this.txt_TotalProductos.TabIndex = 28;
            this.txt_TotalProductos.Text = "$0,00";
            this.txt_TotalProductos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txt_CostoEnvio
            // 
            this.txt_CostoEnvio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.txt_CostoEnvio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_CostoEnvio.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CostoEnvio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.txt_CostoEnvio.Location = new System.Drawing.Point(7, 106);
            this.txt_CostoEnvio.Multiline = true;
            this.txt_CostoEnvio.Name = "txt_CostoEnvio";
            this.txt_CostoEnvio.Size = new System.Drawing.Size(127, 18);
            this.txt_CostoEnvio.TabIndex = 28;
            this.txt_CostoEnvio.Text = "$500,00";
            this.txt_CostoEnvio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // op_Tarjeta
            // 
            this.op_Tarjeta.AutoSize = true;
            this.op_Tarjeta.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.op_Tarjeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.op_Tarjeta.Location = new System.Drawing.Point(6, 208);
            this.op_Tarjeta.Name = "op_Tarjeta";
            this.op_Tarjeta.Size = new System.Drawing.Size(176, 26);
            this.op_Tarjeta.TabIndex = 24;
            this.op_Tarjeta.TabStop = true;
            this.op_Tarjeta.Text = "Tarjeta de Débito/Crédito";
            this.op_Tarjeta.UseVisualStyleBackColor = true;
            this.op_Tarjeta.CheckedChanged += new System.EventHandler(this.op_Tarjeta_CheckedChanged);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Poppins Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.label12.Location = new System.Drawing.Point(3, 159);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(263, 25);
            this.label12.TabIndex = 18;
            this.label12.Text = "Seleccionar forma de pago";
            // 
            // op_Efectivo
            // 
            this.op_Efectivo.AutoSize = true;
            this.op_Efectivo.Font = new System.Drawing.Font("Poppins", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.op_Efectivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.op_Efectivo.Location = new System.Drawing.Point(6, 186);
            this.op_Efectivo.Name = "op_Efectivo";
            this.op_Efectivo.Size = new System.Drawing.Size(74, 26);
            this.op_Efectivo.TabIndex = 23;
            this.op_Efectivo.TabStop = true;
            this.op_Efectivo.Text = "Efectivo";
            this.op_Efectivo.UseVisualStyleBackColor = true;
            this.op_Efectivo.CheckedChanged += new System.EventHandler(this.op_Efectivo_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.panel2.Controls.Add(this.btn_Atras2);
            this.panel2.Controls.Add(this.pic_Logo2);
            this.panel2.Controls.Add(this.btn_Seguir2);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lbl_Ingresar);
            this.panel2.Location = new System.Drawing.Point(349, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(320, 561);
            this.panel2.TabIndex = 26;
            // 
            // btn_Atras2
            // 
            this.btn_Atras2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(166)))), ((int)(((byte)(202)))));
            this.btn_Atras2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(166)))), ((int)(((byte)(202)))));
            this.btn_Atras2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Atras2.BorderRadius = 20;
            this.btn_Atras2.BorderSize = 0;
            this.btn_Atras2.FlatAppearance.BorderSize = 0;
            this.btn_Atras2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Atras2.Font = new System.Drawing.Font("Glacial Indifference", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Atras2.ForeColor = System.Drawing.Color.White;
            this.btn_Atras2.Location = new System.Drawing.Point(17, 506);
            this.btn_Atras2.Name = "btn_Atras2";
            this.btn_Atras2.Size = new System.Drawing.Size(117, 40);
            this.btn_Atras2.TabIndex = 33;
            this.btn_Atras2.Text = "Atrás";
            this.btn_Atras2.TextColor = System.Drawing.Color.White;
            this.btn_Atras2.UseVisualStyleBackColor = false;
            this.btn_Atras2.Click += new System.EventHandler(this.btn_Atras2_Click);
            // 
            // pic_Logo2
            // 
            this.pic_Logo2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pic_Logo2.BackgroundImage")));
            this.pic_Logo2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_Logo2.InitialImage = null;
            this.pic_Logo2.Location = new System.Drawing.Point(10, 3);
            this.pic_Logo2.Name = "pic_Logo2";
            this.pic_Logo2.Size = new System.Drawing.Size(300, 94);
            this.pic_Logo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Logo2.TabIndex = 32;
            this.pic_Logo2.TabStop = false;
            // 
            // btn_Seguir2
            // 
            this.btn_Seguir2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Seguir2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Seguir2.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Seguir2.BorderRadius = 20;
            this.btn_Seguir2.BorderSize = 0;
            this.btn_Seguir2.FlatAppearance.BorderSize = 0;
            this.btn_Seguir2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Seguir2.Font = new System.Drawing.Font("Glacial Indifference", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Seguir2.ForeColor = System.Drawing.Color.White;
            this.btn_Seguir2.Location = new System.Drawing.Point(182, 506);
            this.btn_Seguir2.Name = "btn_Seguir2";
            this.btn_Seguir2.Size = new System.Drawing.Size(117, 40);
            this.btn_Seguir2.TabIndex = 27;
            this.btn_Seguir2.Text = "Continuar";
            this.btn_Seguir2.TextColor = System.Drawing.Color.White;
            this.btn_Seguir2.UseVisualStyleBackColor = false;
            this.btn_Seguir2.Click += new System.EventHandler(this.btn_Seguir2_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.pnl_Ruta);
            this.panel4.Location = new System.Drawing.Point(0, 100);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(320, 397);
            this.panel4.TabIndex = 22;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(230)))), ((int)(((byte)(239)))));
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.pic_Logo4);
            this.panel5.Controls.Add(this.btn_Cerrar);
            this.panel5.Location = new System.Drawing.Point(1026, 15);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(320, 561);
            this.panel5.TabIndex = 36;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Poppins", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.label2.Location = new System.Drawing.Point(19, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(282, 34);
            this.label2.TabIndex = 48;
            this.label2.Text = "¡Tu pedido está en camino!";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.PuntoApuntoB;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(73, 333);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(178, 155);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 37;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.pantera;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(50, 190);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(224, 122);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // pic_Logo4
            // 
            this.pic_Logo4.BackgroundImage = global::TP1_TP6_ISW.Properties.Resources.Header;
            this.pic_Logo4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pic_Logo4.Location = new System.Drawing.Point(10, 3);
            this.pic_Logo4.Name = "pic_Logo4";
            this.pic_Logo4.Size = new System.Drawing.Size(300, 94);
            this.pic_Logo4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pic_Logo4.TabIndex = 33;
            this.pic_Logo4.TabStop = false;
            // 
            // btn_Cerrar
            // 
            this.btn_Cerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Cerrar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(137)))), ((int)(((byte)(184)))));
            this.btn_Cerrar.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.btn_Cerrar.BorderRadius = 20;
            this.btn_Cerrar.BorderSize = 0;
            this.btn_Cerrar.FlatAppearance.BorderSize = 0;
            this.btn_Cerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cerrar.Font = new System.Drawing.Font("Glacial Indifference", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cerrar.ForeColor = System.Drawing.Color.White;
            this.btn_Cerrar.Location = new System.Drawing.Point(35, 506);
            this.btn_Cerrar.Name = "btn_Cerrar";
            this.btn_Cerrar.Size = new System.Drawing.Size(251, 40);
            this.btn_Cerrar.TabIndex = 35;
            this.btn_Cerrar.Text = "Cerrar";
            this.btn_Cerrar.TextColor = System.Drawing.Color.White;
            this.btn_Cerrar.UseVisualStyleBackColor = false;
            this.btn_Cerrar.Click += new System.EventHandler(this.btn_Cerrar_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 561);
            this.ControlBox = false;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DeliverEat!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Fecha)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_BorrarImagen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_ImagenAdjunta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            this.pnl_Ruta.ResumeLayout(false);
            this.pnl_Ruta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Mapa2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Mapa)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo3)).EndInit();
            this.pnl_Tarjeta.ResumeLayout(false);
            this.pnl_Tarjeta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_VisaGris)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Visa)).EndInit();
            this.pnl_Efectivo.ResumeLayout(false);
            this.pnl_Efectivo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_EfectivoPagar)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Logo4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txt_Productos;
        private System.Windows.Forms.Label lbl_Direccion;
        private System.Windows.Forms.Label lbl_DirComercio;
        private System.Windows.Forms.TextBox txt_DirComercio;
        private System.Windows.Forms.Label lbl_CiudadComercio;
        private System.Windows.Forms.ComboBox cmb_CiudadComercio;
        private System.Windows.Forms.Label lbl_PedidoPersonalizado;
        private System.Windows.Forms.Label lbl_ReferenciaComercio;
        private System.Windows.Forms.Label lbl_CaracteresRef;
        private System.Windows.Forms.TextBox txt_ReferenciaComercio;
        private System.Windows.Forms.TextBox txt_CostoTotal;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Panel pnl_Ruta;
        private System.Windows.Forms.Label lbl_Ingresar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton op_IngresarFechaHora;
        private System.Windows.Forms.RadioButton op_LoAntesPosible;
        private System.Windows.Forms.Label lbl_Cuando;
        private System.Windows.Forms.Label lbl_RefDomicilio;
        private System.Windows.Forms.Label lbl_CaracteresRef2;
        private System.Windows.Forms.TextBox txt_RefDomicilio;
        private System.Windows.Forms.Label lbl_Domicilio;
        private System.Windows.Forms.Label lbl_DirDomicilio;
        private System.Windows.Forms.Label lbl_CiudadDomicilio;
        private System.Windows.Forms.TextBox txt_DirDomicilio;
        private System.Windows.Forms.ComboBox cmb_CiudadDomicilio;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton op_Efectivo;
        private System.Windows.Forms.Panel pnl_Efectivo;
        private System.Windows.Forms.RadioButton op_Tarjeta;
        private System.Windows.Forms.Panel pnl_Tarjeta;
        private System.Windows.Forms.Label lblTarjeta;
        private System.Windows.Forms.Label lbl_NroTarjeta;
        private System.Windows.Forms.Label lbl_FechaVencimiento;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_NombreApellidoTitular;
        private System.Windows.Forms.Label lbl_CVC;
        private Negocio.BotonRedondo btn_Seguir;
        private Negocio.BotonRedondo btn_Confirmar;
        private Negocio.BotonRedondo btn_Seguir2;
        private System.Windows.Forms.MaskedTextBox txt_NumeroTarjeta;
        private System.Windows.Forms.PictureBox pic_Visa;
        private System.Windows.Forms.PictureBox pic_VisaGris;
        private System.Windows.Forms.PictureBox pic_ImagenAdjunta;
        private System.Windows.Forms.MaskedTextBox txt_FechaEntrega;
        private System.Windows.Forms.MaskedTextBox txt_CodigoSeguridad;
        private System.Windows.Forms.MaskedTextBox txt_Vencimiento;
        private System.Windows.Forms.Label lbl_CostoProductos;
        private System.Windows.Forms.TextBox txt_TotalProductos;
        private System.Windows.Forms.TextBox txt_CostoEnvio;
        private System.Windows.Forms.PictureBox pic_Logo1;
        private System.Windows.Forms.TextBox lbl_EnProductos;
        private System.Windows.Forms.TextBox lbl_EnTotal;
        private System.Windows.Forms.TextBox lbl_EnEnvio;
        private System.Windows.Forms.PictureBox pic_Logo3;
        private System.Windows.Forms.PictureBox pic_Logo2;
        private System.Windows.Forms.PictureBox pic_Mapa;
        private System.Windows.Forms.PictureBox pic_Mapa2;
        private System.Windows.Forms.PictureBox pic_BorrarImagen;
        private System.Windows.Forms.Label lbl_Fin;
        private Negocio.BotonRedondo btn_Atras3;
        private Negocio.BotonRedondo btn_Atras2;
        private System.Windows.Forms.MaskedTextBox txt_CostoProductos;
        private System.Windows.Forms.MaskedTextBox txt_EfectivoAPagar;
        private System.Windows.Forms.Label label1;
        private Negocio.BotonRedondo btn_AgregarFoto;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pic_Logo4;
        private Negocio.BotonRedondo btn_Cerrar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_CaracteresProd;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pic_EfectivoPagar;
        private System.Windows.Forms.PictureBox pic_Fecha;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
    }
}

