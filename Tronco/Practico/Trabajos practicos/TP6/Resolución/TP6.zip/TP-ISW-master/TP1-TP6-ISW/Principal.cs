﻿using NAudio.Wave;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP1_TP6_ISW
{
    public partial class Principal : Form
    {

        Random random = new Random();
        private WaveOutEvent outputDevice;
        private AudioFileReader audioFile;

        public Principal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            OpcionesPorDefecto();
            CargarColores();
            CargarCiudades();
            EstadoTextBoxTarjeta(false);
            EstadoTextBoxFecha(false);
        }

        private void OpcionesPorDefecto()
        {
            op_LoAntesPosible.Checked = true;
            op_Efectivo.Checked = true;

            panel2.Hide();
            panel3.Hide();
            panel5.Hide();
        }

        private void CargarColores()
        {
            ColoresBotones(btn_Confirmar, "#B8BEDD", false);
            ColoresBotones(btn_Seguir, "#B8BEDD", false);
            ColoresBotones(btn_Seguir2, "#B8BEDD", false);
            ColoresBotones(btn_AgregarFoto, "#B8BEDD", false);
            ColoresBotones(btn_Atras2, "#EFC3E6", false);
            ColoresBotones(btn_Atras3, "#EFC3E6", false);
            ColoresBotones(btn_Cerrar, "#B8BEDD", false);

            ColoresTextBox();
        }

        private void ColoresBotones(Button boton, string colorHexa, bool esNegrita)
        {
            boton.BackColor = ColorTranslator.FromHtml(colorHexa);

            if (esNegrita) boton.Font = new Font(boton.Font, FontStyle.Bold);
        }

        private void ColoresTextBox()
        {
            txt_Productos.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_CostoProductos.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_FechaEntrega.ForeColor = ColorTranslator.FromHtml("#9C89B8");

            txt_DirComercio.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_ReferenciaComercio.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            cmb_CiudadComercio.ForeColor = ColorTranslator.FromHtml("#9C89B8");

            txt_DirDomicilio.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_RefDomicilio.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            cmb_CiudadDomicilio.ForeColor = ColorTranslator.FromHtml("#9C89B8");

            txt_NumeroTarjeta.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_Vencimiento.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_NombreApellidoTitular.ForeColor = ColorTranslator.FromHtml("#9C89B8");
            txt_CodigoSeguridad.ForeColor = ColorTranslator.FromHtml("#9C89B8");
        }

        private void txt_Productos_TextChanged(object sender, EventArgs e)
        {
            CambiarLabelLimiteTexto(lbl_CaracteresProd, txt_Productos, 240);
        }

        private void txt_ReferenciaComercio_TextChanged(object sender, EventArgs e)
        {
            CambiarLabelLimiteTexto(lbl_CaracteresRef, txt_ReferenciaComercio, 240);
        }

        private void CambiarLabelLimiteTexto(Label label, TextBox textbox, int limiteCaracteres)
        {
            int caracteresEscritos = textbox.Text.Length;

            label.Text = caracteresEscritos + "/" + limiteCaracteres;
        }

        private void CargarCiudades()
        {
            string[] ciudades = {"Córdoba", "Carlos Paz"};

            cmb_CiudadComercio.Items.AddRange(ciudades);
            cmb_CiudadDomicilio.Items.AddRange(ciudades);
        }

        private void EstadoTextBoxTarjeta(bool estado)
        {
            txt_NumeroTarjeta.Enabled = estado;
            txt_CodigoSeguridad.Enabled = estado;
            txt_NombreApellidoTitular.Enabled = estado;
            txt_Vencimiento.Enabled = estado;

            txt_EfectivoAPagar.Enabled = !estado;
            txt_EfectivoAPagar.Visible = !estado;
            pic_EfectivoPagar.Visible = !estado;
        }

        private void EstadoTextBoxFecha(bool estado)
        {
            txt_FechaEntrega.Enabled = estado;
            txt_FechaEntrega.Visible = estado;
            pic_Fecha.Visible = estado;
        }

        private void op_Tarjeta_CheckedChanged(object sender, EventArgs e)
        {
            EstadoTextBoxTarjeta(true);
        }

        private void op_Efectivo_CheckedChanged(object sender, EventArgs e)
        {
            EstadoTextBoxTarjeta(false);
        }

        private void op_IngresarFechaHora_CheckedChanged(object sender, EventArgs e)
        {
            EstadoTextBoxFecha(true);
        }

        private void op_LoAntesPosible_CheckedChanged(object sender, EventArgs e)
        {
            EstadoTextBoxFecha(false);
        }

        private void txt_Productos_Click(object sender, EventArgs e)
        {
            LimpiarTextBox(txt_Productos, "Ingrese los productos aqui.");
        }

        private void cmb_CiudadComercio_Validating(object sender, CancelEventArgs e)
        {
            ComboBox combo = (ComboBox)sender;
            string entrada = combo.Text;

            if (!combo.Items.Contains(entrada))
            {
                combo.Text = combo.Items[0].ToString();
            }

            if (combo.Text == "Córdoba")
            {
                Image image = Image.FromFile(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Resources\\mapa_Co.png"));
                pic_Mapa.Image = image;
                pic_Mapa.SizeMode = PictureBoxSizeMode.CenterImage;
            }

            if (combo.Text == "Carlos Paz")
            {
                Image image = Image.FromFile(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Resources\\mapa_Cp.png"));
                pic_Mapa.Image = image;
                pic_Mapa.SizeMode = PictureBoxSizeMode.CenterImage;
            }
        }

        private void txt_NumeroTarjeta_TextChanged(object sender, EventArgs e)
        {
            if (txt_NumeroTarjeta.Text[0].ToString() == "4")
            {
                pic_Visa.Visible = true;
                pic_VisaGris.Visible = false;
            }
            else
            {
                pic_Visa.Visible = false;
                pic_VisaGris.Visible = true;
            }
        }

        private void btn_Seguir_Click(object sender, EventArgs e)
        {
            if (ValidarPantallaUno())
            {
                CalcularTotales();

                panel1.Hide();

                panel2.Location = panel1.Location;

                panel2.Show();
            }
        }

        private bool ValidarPantallaUno()
        {
            if (txt_Productos.Text.Length == 0 || txt_Productos.Text == "Ingrese los productos aqui.")
            {
                MessageBox.Show("El campo de productos está vacío, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_CostoProductos.Text == "$___.___.___,__" || txt_CostoProductos.Text == "")
            {
                MessageBox.Show("El campo de costo está vacío, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (op_IngresarFechaHora.Checked)
            {
                string fechaIngresada = txt_FechaEntrega.Text;
                DateTime fechaValida;

                if (!DateTime.TryParseExact(fechaIngresada, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out fechaValida))
                {
                    MessageBox.Show("La fecha y hora ingresadas no son válidas, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (fechaValida < DateTime.Now)
                {
                    MessageBox.Show("La fecha ingresada es menor a la fecha actual, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (fechaValida.Hour < 7)
                {
                    MessageBox.Show("El horario de atención es de las 7 a 23:59, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (fechaValida > DateTime.Now.AddDays(6).Date.AddHours(23).AddMinutes(59))
                {
                    MessageBox.Show("La fecha del pedido solo se pueden programar hasta 7 días desde el día actual, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }

            return true;
        }

        private bool ValidarPantallaTres()
        {
            if (op_Efectivo.Checked)
            {

                if (txt_EfectivoAPagar.Text == "$___.___.___,__" || txt_EfectivoAPagar.Text == "")
                {
                    MessageBox.Show("El campo de efectivo a pagar está vacío, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (decimal.TryParse(txt_CostoTotal.Text.Replace("$", ""), NumberStyles.Currency, new CultureInfo("es-AR"), out decimal montoTotalAPagar) && 
                    decimal.TryParse(txt_EfectivoAPagar.Text.Replace("$", ""), NumberStyles.Currency, new CultureInfo("es-AR"), out decimal montoEfectivoCliente))
                {
                    if (montoEfectivoCliente < montoTotalAPagar)
                    {
                        MessageBox.Show("Debe pagar al menos el mismo monto correspondiente al total, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }

                return true;
            }

            if (txt_NombreApellidoTitular.Text.Length == 0 || txt_NombreApellidoTitular.Text == "Ingrese el nombre aquí.")
            {
                MessageBox.Show("El campo de nombre y apellido del titular está vacío, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_CodigoSeguridad.Text.Length != 3 || !txt_CodigoSeguridad.Text.All(char.IsDigit))
            {
                MessageBox.Show("El código de seguridad ingresado es inválido, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_Vencimiento.Text.Replace(" ", "") == "/")
            {
                MessageBox.Show("La campo de fecha de vencimiento está vacío, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            string numeroTarjetaFormateado = new string(txt_NumeroTarjeta.Text.Where(char.IsDigit).ToArray());
            int cantidadDigitos = numeroTarjetaFormateado.Length;

            if (txt_NumeroTarjeta.Text[0].ToString() == "4" && cantidadDigitos == 16)
            {
                DateTime fechaActual = DateTime.Now;
                string fechaIngresada = txt_Vencimiento.Text;

                if (DateTime.TryParseExact(fechaIngresada, "MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime fechaVencimiento))
                {
                    fechaVencimiento = new DateTime(fechaVencimiento.Year, fechaVencimiento.Month, 1);

                    if (fechaVencimiento < fechaActual)
                    {
                        MessageBox.Show("La tarjeta ingresada es inválida, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            else
            {
                MessageBox.Show("La tarjeta ingresada es inválida, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private bool ValidarPantallaDos()
        {
            if (txt_DirComercio.Text == "" || txt_DirComercio.Text == "Ingrese el nombre y número de la calle aquí.")
            {
                MessageBox.Show("La dirección ingresada no puede ser vacía, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_DirDomicilio.Text == "" || txt_DirDomicilio.Text == "Ingrese el nombre y número de la calle aquí.")
            {
                MessageBox.Show("La dirección ingresada no puede ser vacía, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_CiudadComercio.SelectedIndex == -1 || cmb_CiudadDomicilio.SelectedIndex == -1)
            {
                MessageBox.Show("La ciudad ingresada no puede ser vacía, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btn_AgregarFoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Title = "Adjunta tu foto";
            openFileDialog.Filter = "Archivos de imagen JPG (*.jpg)|*.jpg|Todos los archivos (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                if (Path.GetExtension(openFileDialog.FileName).Equals(".jpg", StringComparison.OrdinalIgnoreCase))
                {
                    string archivoSeleccionado = openFileDialog.FileName;

                    FileInfo fileInfo = new FileInfo(archivoSeleccionado);
                    long tamañoArchivoEnBytes = fileInfo.Length;
                    long tamañoMaximoEnBytes = 5242880; // 5MB

                    if (tamañoArchivoEnBytes > tamañoMaximoEnBytes)
                    {
                        MessageBox.Show("El tamaño del archivo es superior a 5MB, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string rutaDelArchivo = archivoSeleccionado;

                        Image imagenRedimensionada = RedimensionarImagen(Image.FromFile(rutaDelArchivo), 64, 64);
                        pic_ImagenAdjunta.Image = imagenRedimensionada;

                        pic_ImagenAdjunta.SizeMode = PictureBoxSizeMode.CenterImage;
                        pic_ImagenAdjunta.Anchor = AnchorStyles.None;

                        pic_BorrarImagen.Visible = true;
                    }
                }
                else
                {
                    MessageBox.Show("El archivo seleccionado no es formato .jpg, reintente.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private Bitmap RedimensionarImagen(Image image, int width, int height)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }

        private void btn_Confirmar_Click(object sender, EventArgs e)
        {
            if (ValidarPantallaTres())
            {
                ReproducirSonido();

                panel3.Hide();

                panel5.Location = panel3.Location;

                panel5.Show();
            }
        }

        private void ReproducirSonido()
        {
            if (outputDevice != null && outputDevice.PlaybackState == PlaybackState.Playing)
            {
                outputDevice.Stop();
                outputDevice.Dispose();
                audioFile.Dispose();
            }

            string appDirectory = Path.GetDirectoryName(Application.ExecutablePath);

            string mp3FileName = "Resources\\lavender_haze.mp3";
            string mp3FilePath = Path.Combine(appDirectory, mp3FileName);

            outputDevice = new WaveOutEvent();
            audioFile = new AudioFileReader(mp3FilePath);

            outputDevice.Init(audioFile);
            outputDevice.Play();
        }

        private void btn_Seguir2_Click(object sender, EventArgs e)
        {
            if (ValidarPantallaDos())
            {
                panel2.Hide();

                panel3.Location = panel2.Location;

                panel3.Show();
            }
        }

        private void CalcularTotales()
        {
            if (txt_CostoProductos.Text[0] != '$')
            {
                txt_TotalProductos.Text = "$" + txt_CostoProductos.Text;
            }

            if (txt_CostoProductos.Text.Length >= 13)
            {
                string costoProductosRecortado = txt_CostoProductos.Text.Replace(" ", "").Substring(0, Math.Min(txt_CostoProductos.Text.Replace(" ", "").Length, 10)) + "+";
                txt_TotalProductos.Text = costoProductosRecortado;
            }
            else
            {
                txt_TotalProductos.Text = txt_CostoProductos.Text.Replace(" ", "");
            }

            string costoProductosLimpio = txt_CostoProductos.Text.Replace(" ", "").Replace("$", "");

            decimal costoEnvio = 500;
            decimal costoTotal;

            if (decimal.TryParse(costoProductosLimpio, out decimal costoProductosDecimal))
            {
                costoTotal = costoProductosDecimal + costoEnvio;
                string totalFormateado = costoTotal.ToString("C", new CultureInfo("es-AR"));

                if (totalFormateado.Length >= 15)
                {
                    string totalRecortado = totalFormateado.Replace(" ", "").Substring(0, Math.Min(totalFormateado.Replace(" ", "").Length, 10)) + "+";
                    txt_CostoTotal.Text = totalRecortado;
                }
                else
                {
                    txt_CostoTotal.Text = totalFormateado.Replace(" ", "");
                }
            }
        }

        private void txt_RefDomicilio_TextChanged(object sender, EventArgs e)
        {
            CambiarLabelLimiteTexto(lbl_CaracteresRef2, txt_RefDomicilio, 240);
        }

        private void cmb_CiudadDomicilio_Validating(object sender, CancelEventArgs e)
        {
            ComboBox combo = (ComboBox)sender;
            string entrada = combo.Text;

            if (!combo.Items.Contains(entrada))
            {
                combo.Text = combo.Items[0].ToString();
            }

            if (combo.Text == "Córdoba")
            {
                Image image = Image.FromFile(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Resources\\mapa_Co.png"));
                pic_Mapa2.Image = image;
                pic_Mapa2.SizeMode = PictureBoxSizeMode.CenterImage;
            }

            if (combo.Text == "Carlos Paz")
            {
                Image image = Image.FromFile(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "Resources\\mapa_Cp.png"));
                pic_Mapa2.Image = image;
                pic_Mapa2.SizeMode = PictureBoxSizeMode.CenterImage;
            }
        }

        private void GenerarDireccionAleatoria(TextBox textbox)
        {
            string[] direcciones = {
                                    "Pueyrredon 154",
                                    "Crisol 215",
                                    "Belgrano 367",
                                    "San Martin 102",
                                    "Independencia 721",
                                    "Colon 480",
                                    "General Paz 893",
                                    "Laprida 662",
                                    "Rivadavia 531",
                                    "Buenos Aires 299",
                                    "Rioja 408",
                                    "Santa Rosa 177",
                                    "Maipu 615",
                                    "Obispo Trejo 936",
                                    "La Rioja 811",
                                    "Obispo Salguero 1245",
                                    "San Jeronimo 328",
                                    "Avenida Velez Sarsfield 1588",
                                    "Santa Fe 609",
                                    "Jujuy 753",
                                    "Dean Funes 440",
                                    "Tucuman 276",
                                    "Lima 190",
                                    "Ituzaingo 753",
                                    "Alvear 345",
                                    "Balcarce 621",
                                    "Las Heras 987",
                                    "Chacabuco 132",
                                    "Obispo Oro 345",
                                    "San Lorenzo 789",
                                    "Ayacucho 654",
                                    "Lavalle 512",
                                    "Rondeau 220",
                                    "Sarmiento 963",
                                    "Avellaneda 150",
                                    "Entre Rios 842",
                                    "Boulevard San Juan 407",
                                    "Rio Negro 529",
                                    "Tribunales 803",
                                    "Maestro Vidal 114"
                                };

            int indiceAleatorio = random.Next(0, direcciones.Length);
            string direccionAleatoria = direcciones[indiceAleatorio];

            textbox.Text = direccionAleatoria;
        }

        private void pic_Mapa_Click(object sender, EventArgs e)
        {
            GenerarDireccionAleatoria(txt_DirComercio);

            if (cmb_CiudadComercio.Text == "Carlos Paz")
            {
                cmb_CiudadComercio.Text = "Carlos Paz";
            }
            else
            {
                cmb_CiudadComercio.Text = "Córdoba";
            }
        }

        private void pic_Mapa2_Click(object sender, EventArgs e)
        {
            GenerarDireccionAleatoria(txt_DirDomicilio);

            if (cmb_CiudadDomicilio.Text == "Carlos Paz")
            {
                cmb_CiudadDomicilio.Text = "Carlos Paz";
            }
            else
            {
                cmb_CiudadDomicilio.Text = "Córdoba";
            }
        }

        private void pic_BorrarImagen_Click(object sender, EventArgs e)
        {
            pic_ImagenAdjunta.Image = null;
            pic_BorrarImagen.Visible = false;
        }

        private void txt_DirComercio_Click(object sender, EventArgs e)
        {
            LimpiarTextBox(txt_DirComercio, "Ingrese el nombre y número de la calle aquí.");
        }

        private void txt_DirDomicilio_Click(object sender, EventArgs e)
        {
            LimpiarTextBox(txt_DirDomicilio, "Ingrese el nombre y número de la calle aquí.");
        }

        private void txt_RefDomicilio_Click(object sender, EventArgs e)
        {
            LimpiarTextBox(txt_RefDomicilio, "Indicaciones de referencia.");
        }

        private void txt_ReferenciaComercio_Click(object sender, EventArgs e)
        {
            LimpiarTextBox(txt_ReferenciaComercio, "Indicaciones de referencia.");
        }

        private void txt_NombreApellidoTitular_Click(object sender, EventArgs e)
        {
            LimpiarTextBox(txt_NombreApellidoTitular, "Ingrese el nombre aquí.");
        }

        private void LimpiarTextBox(TextBox textBox, string textoABorrar)
        {
            if (textBox.Text == textoABorrar)
            {
                textBox.Clear();
            }
        }

        private void btn_Atras2_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel2.Hide();
        }

        private void btn_Atras3_Click(object sender, EventArgs e)
        {
            panel2.Show();
            panel3.Hide();
        }

        private void txt_CostoProductos_format_Click(object sender, EventArgs e)
        {
            LimpiarMaskedTextBox(txt_CostoProductos, "$___.___.___,__");
        }

        private void txt_EfectivoAPagar_Click(object sender, EventArgs e)
        {
            LimpiarMaskedTextBox(txt_EfectivoAPagar, "$___.___.___,__");
        }

        private void LimpiarMaskedTextBox(MaskedTextBox textBoxCosto, string textoABorrar)
        {
            if (textBoxCosto.Text == textoABorrar)
            {
                textBoxCosto.Clear();
            }
        }

        private void txt_CostoProductos_format_TextChanged(object sender, EventArgs e)
        {
            string valorLimpiado = Regex.Replace(txt_CostoProductos.Text, @"[^0-9.,]", "");
            txt_CostoProductos.Text = valorLimpiado;

            string valor = txt_CostoProductos.Text.Replace(",", "").Replace("$", "").Replace(".", "").TrimStart('0');

            if (decimal.TryParse(valor, out decimal ul))
            {
                ul /= 100;

                txt_CostoProductos.TextChanged -= txt_CostoProductos_format_TextChanged;
                txt_CostoProductos.Text = string.Format(CultureInfo.CreateSpecificCulture("es-AR"), "{0:C2}", ul);
                txt_CostoProductos.TextChanged += txt_CostoProductos_format_TextChanged;
                txt_CostoProductos.Select(txt_CostoProductos.Text.Length, 0);
            }
        }

        private void txt_EfectivoAPagar_TextChanged(object sender, EventArgs e)
        {
            string valorLimpiado = Regex.Replace(txt_EfectivoAPagar.Text, @"[^0-9.,]", "");
            txt_EfectivoAPagar.Text = valorLimpiado;

            string valor = txt_EfectivoAPagar.Text.Replace(",", "").Replace("$", "").Replace(".", "").TrimStart('0');

            if (decimal.TryParse(valor, out decimal ul))
            {
                ul /= 100;
                txt_EfectivoAPagar.TextChanged -= txt_EfectivoAPagar_TextChanged;
                txt_EfectivoAPagar.Text = string.Format(CultureInfo.CreateSpecificCulture("es-AR"), "{0:C2}", ul);
                txt_EfectivoAPagar.TextChanged += txt_EfectivoAPagar_TextChanged;
                txt_EfectivoAPagar.Select(txt_CostoProductos.Text.Length, 0);
            }
        }

        private void btn_Cerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txt_CostoProductos_Leave(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txt_CostoProductos.Text, @"^[0.,]+$"))
            {
                txt_CostoProductos.Text = "$0,00";
            }
        }

        private void txt_EfectivoAPagar_Leave(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txt_EfectivoAPagar.Text, @"^[0.,]+$"))
            {
                txt_EfectivoAPagar.Text = "$0,00";
            }
        }

        private void txt_NumeroTarjeta_EnabledChanged(object sender, EventArgs e)
        {
            CambiarBackColorTextBox(txt_NumeroTarjeta);
        }

        private void txt_NombreApellidoTitular_EnabledChanged(object sender, EventArgs e)
        {
            CambiarBackColorTextBox(txt_NombreApellidoTitular);
        }

        private void txt_Vencimiento_EnabledChanged(object sender, EventArgs e)
        {
            CambiarBackColorTextBox(txt_Vencimiento);
        }

        private void txt_CodigoSeguridad_EnabledChanged(object sender, EventArgs e)
        {
            CambiarBackColorTextBox(txt_CodigoSeguridad);
        }

        private void CambiarBackColorTextBox(MaskedTextBox textBox)
        {
            if (textBox.Enabled)
            {
                textBox.BackColor = Color.White;
            }
            else
            {
                textBox.BackColor = Color.White;
            }
        }

        private void CambiarBackColorTextBox(TextBox textBox)
        {
            if (textBox.Enabled)
            {
                textBox.BackColor = Color.White;
            }
            else
            {
                textBox.BackColor = Color.White;
            }
        }
    }
}
